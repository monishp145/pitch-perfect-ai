# 🎤 PitchPerfect AI

**From raw startup idea to boardroom-ready pitch — powered by Claude AI + Murf.ai voice synthesis.**

PitchPerfect AI is a virtual pitch coach for student entrepreneurs. Input your rough startup idea, get a professional AI-generated script, and hear it narrated back to you in Murf.ai's Promo or Authoritative voice styles.

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone <your-repo>
cd pitchperfect-ai
npm install
```

### 2. Set Up Environment Variables

```bash
cp .env.example .env
```

Open `.env` and add your API keys:

```env
VITE_ANTHROPIC_API_KEY=your_anthropic_api_key_here
VITE_MURF_API_KEY=your_murf_api_key_here
```

**Where to get your keys:**
- **Anthropic API Key** → https://console.anthropic.com → API Keys
- **Murf.ai API Key** → https://murf.ai/api → Sign up for developer access

### 3. Run the Dev Server

```bash
npm run dev
```

Open http://localhost:3000 in your browser.

### 4. Build for Production

```bash
npm run build
npm run preview
```

---

## 📁 Project Structure

```
pitchperfect-ai/
├── public/
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── Navbar.jsx / .css       # Fixed navigation bar
│   │   ├── Footer.jsx / .css       # Site footer
│   │   ├── AudioPlayer.jsx / .css  # Custom audio player with waveform
│   │   ├── ScriptEditor.jsx / .css # View/edit generated pitch script
│   │   └── FeedbackPanel.jsx / .css # AI coach score & suggestions
│   ├── hooks/
│   │   └── usePitchGenerator.js    # Central state machine for generation flow
│   ├── pages/
│   │   ├── LandingPage.jsx / .css  # Home / marketing page
│   │   ├── PitchStudio.jsx / .css  # Main app interface
│   │   └── HowItWorks.jsx / .css   # Process & FAQ page
│   ├── services/
│   │   ├── anthropicService.js     # Claude API integration (script + feedback)
│   │   └── murfService.js          # Murf.ai TTS integration
│   ├── styles/
│   │   └── global.css              # Design system, tokens, base styles
│   ├── App.jsx                     # Router & layout wrapper
│   └── main.jsx                    # React entry point
├── index.html
├── vite.config.js
├── package.json
├── .env.example
└── README.md
```

---

## 🔌 API Integration Details

### Claude AI (Anthropic)
- **Model:** `claude-sonnet-4-20250514`
- **Script Generation:** Structured prompt with pitch type, duration, and voice style guides
- **Feedback:** Returns JSON with score (0-100), strengths, improvements, and power phrase
- **Endpoint:** `https://api.anthropic.com/v1/messages`

### Murf.ai
- **Endpoint:** `https://api.murf.ai/v1/speech/generate`
- **Promo Voice:** `en-US-natalie` — energetic, upbeat, marketing-oriented
- **Authoritative Voice:** `en-US-marcus` — deep, confident, executive-level
- **Output:** MP3, 48kHz, stereo
- **Docs:** https://murf.ai/api/docs

> **Note on Murf Voice IDs:** Voice IDs may vary by your Murf plan. Check your Murf dashboard for available voices and update `src/services/murfService.js` accordingly.

---

## 🎨 Design System

| Token | Value | Usage |
|-------|-------|-------|
| `--ink` | `#0a0a0a` | Primary background |
| `--ivory` | `#f5f0e8` | Primary text |
| `--gold` | `#c9a84c` | Accent / brand |
| `--slate` | `#1e2235` | Card backgrounds |
| `--smoke` | `#8b8fa8` | Secondary text |

**Fonts:** Bebas Neue (display) · DM Serif Display (body serif) · Syne (UI) · Space Mono (code/labels)

---

## 🛠 Customizing Voice IDs

To use different Murf voices, edit `src/services/murfService.js`:

```js
export const MURF_VOICES = {
  Promo: {
    voiceId: 'en-US-natalie',  // Change this
    style: 'Promo',
    ...
  },
  Authoritative: {
    voiceId: 'en-US-marcus',   // Change this
    style: 'Authoritative',
    ...
  },
}
```

Find available voice IDs at: https://murf.ai/api/docs#voices

---

## 🚢 Deployment

### Vercel (Recommended)
```bash
npm install -g vercel
vercel
```
Add environment variables in Vercel dashboard under Project Settings → Environment Variables.

### Netlify
```bash
npm run build
# Deploy the `dist/` folder
```
Add env vars in Netlify dashboard under Site Settings → Environment Variables.

---

## ⚡ Pitch Studio — User Flow

1. **Input** → User enters startup idea, selects pitch type, duration, and voice style
2. **Generate** → Claude AI creates a structured pitch script
3. **Review** → User reads, edits, and sees AI feedback score
4. **Listen** → Murf.ai synthesizes the script in chosen voice style
5. **Download** → User saves the MP3 for practice

---

## 🔧 Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `Anthropic API key is missing` | No `.env` file or key | Copy `.env.example` → `.env` and add key |
| `Murf API key is missing` | No Murf key | Add `VITE_MURF_API_KEY` to `.env` |
| `401 from Murf` | Invalid Murf key | Check key in Murf dashboard |
| `No audio returned` | Voice ID not found | Update voice IDs in `murfService.js` |
| CORS errors in dev | Browser blocking API | Uses Vite proxy — run via `npm run dev` |

---

## 📄 License

MIT — free to use, modify, and deploy for educational purposes.
