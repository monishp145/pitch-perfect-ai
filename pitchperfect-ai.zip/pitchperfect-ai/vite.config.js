import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api/murf': {
        target: 'https://api.murf.ai',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/murf/, ''),
        headers: {
          'Origin': 'https://api.murf.ai'
        }
      }
    }
  }
})
