// ============================================
// services/murfService.js
// Murf AI Text-to-Speech Integration
// Docs: https://murf.ai/api/docs
// ============================================

const MURF_API_KEY = import.meta.env.VITE_MURF_API_KEY
const MURF_BASE_URL = 'https://api.murf.ai/v1'

// Murf voice configurations
// Promo style: energetic, upbeat, marketing-oriented
// Authoritative style: confident, professional, executive-level
export const MURF_VOICES = {
  Promo: {
    voiceId: 'en-US-natalie',   // Energetic female voice — great for promo
    style: 'Promo',
    speed: 1.0,
    pitch: 0,
    label: 'Promo — Energetic & Inspiring',
    description: 'Upbeat, emotionally engaging tone perfect for pitches that sell a vision',
    icon: '🔥',
  },
  Authoritative: {
    voiceId: 'en-US-marcus',    // Deep authoritative male voice
    style: 'Authoritative',
    speed: 0.95,
    pitch: -1,
    label: 'Authoritative — Executive & Commanding',
    description: 'Confident, precise delivery that commands boardroom respect',
    icon: '💼',
  },
}

/**
 * Synthesize speech using Murf AI API
 * @param {string} text - The pitch script text
 * @param {string} voiceStyle - 'Promo' or 'Authoritative'
 * @returns {Promise<{audioUrl: string, duration: number}>}
 */
export async function synthesizeSpeech(text, voiceStyle = 'Promo') {
  if (!MURF_API_KEY) {
    throw new Error(
      'Murf API key is missing. Please add VITE_MURF_API_KEY to your .env file. Get your key at https://murf.ai/api'
    )
  }

  const voice = MURF_VOICES[voiceStyle] || MURF_VOICES.Promo

  // Murf AI Speech Synthesis endpoint
  const response = await fetch(`${MURF_BASE_URL}/speech/generate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'api-key': MURF_API_KEY,
    },
    body: JSON.stringify({
      voiceId: voice.voiceId,
      style: voice.style,
      text: text,
      rate: voice.speed,
      pitch: voice.pitch,
      sampleRate: 48000,
      format: 'MP3',
      channelType: 'STEREO',
      pronunciationDictionary: {},
      encodeAsBase64: false,
      variation: 1,
      audioDuration: 0,
      multiNativeLocale: false,
    }),
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}))
    
    // Handle common Murf API errors
    if (response.status === 401) {
      throw new Error('Invalid Murf API key. Please check your VITE_MURF_API_KEY in the .env file.')
    }
    if (response.status === 429) {
      throw new Error('Murf API rate limit exceeded. Please wait a moment and try again.')
    }
    if (response.status === 402) {
      throw new Error('Murf API quota exceeded. Please check your Murf subscription plan.')
    }
    
    throw new Error(errorData?.message || `Murf API error: ${response.status}`)
  }

  const data = await response.json()

  // Murf returns audioFile URL and audioDuration
  if (!data.audioFile) {
    throw new Error('No audio returned from Murf API. Please try again.')
  }

  return {
    audioUrl: data.audioFile,
    duration: data.audioDuration || 0,
    wordDurations: data.wordDurations || [],
  }
}

/**
 * Fetch available voices from Murf (for dynamic voice listing)
 */
export async function getMurfVoices() {
  if (!MURF_API_KEY) return null
  
  try {
    const response = await fetch(`${MURF_BASE_URL}/speech/voices`, {
      headers: { 'api-key': MURF_API_KEY },
    })
    if (!response.ok) return null
    return await response.json()
  } catch {
    return null
  }
}
