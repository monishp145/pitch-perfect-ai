// ============================================
// services/anthropicService.js
// Generates professional pitch scripts via Claude API
// ============================================

const ANTHROPIC_API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY

export async function generatePitchScript({ idea, voiceStyle, pitchType, duration }) {
  if (!ANTHROPIC_API_KEY) {
    throw new Error('Anthropic API key is missing. Please add VITE_ANTHROPIC_API_KEY to your .env file.')
  }

  const durationMap = {
    '30s': '30 seconds (approximately 75-85 words)',
    '60s': '60 seconds (approximately 150-170 words)',
    '2min': '2 minutes (approximately 300-340 words)',
    '5min': '5 minutes (approximately 750-850 words)',
  }

  const voiceStyleGuides = {
    Promo: 'energetic, inspiring, emotionally engaging, uses vivid imagery, builds excitement, uses power words, sounds like a compelling advertisement or TED Talk opener',
    Authoritative: 'confident, data-driven, precise, professional boardroom tone, uses industry terminology appropriately, commands respect, sounds like a seasoned executive presenting to serious investors',
  }

  const pitchTypeGuides = {
    'Elevator Pitch': 'a quick, punchy intro covering the problem, solution, and unique value proposition',
    'Investor Pitch': 'a structured pitch covering problem, solution, market size, business model, traction, team, and ask',
    'Demo Day': 'an engaging, narrative-driven pitch suitable for a startup demo day audience',
    'Product Launch': 'a compelling product announcement pitch emphasizing benefits, features, and call to action',
  }

  const prompt = `You are an elite startup pitch coach who has helped hundreds of founders raise millions in funding. Your job is to transform raw startup ideas into professional, high-impact pitch scripts.

STARTUP IDEA:
${idea}

REQUIREMENTS:
- Duration: ${durationMap[duration] || durationMap['60s']}
- Voice Style: ${voiceStyle} — ${voiceStyleGuides[voiceStyle] || voiceStyleGuides['Promo']}
- Pitch Type: ${pitchType} — ${pitchTypeGuides[pitchType] || pitchTypeGuides['Elevator Pitch']}

SCRIPT STRUCTURE (adapt based on pitch type and duration):
1. Hook — Start with a bold statement, surprising stat, or compelling question
2. Problem — Paint the problem vividly; make the audience feel it
3. Solution — Introduce the startup as the elegant answer
4. Value Proposition — What makes this unique and defensible?
5. Traction/Proof (if duration allows) — Any evidence of momentum
6. Vision — Paint the big picture future
7. Call to Action — Clear next step

VOICE & TONE RULES:
- Write for SPOKEN delivery, not reading
- Use short punchy sentences mixed with longer flowing ones for rhythm
- Include natural pauses via em dashes (—) and ellipses (...)
- Avoid jargon unless absolutely necessary
- Every sentence should earn its place

OUTPUT FORMAT:
Return ONLY the pitch script text. No labels, no stage directions, no markdown headers, no preamble. Just the words to be spoken, ready for text-to-speech conversion.

Write the script now:`

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1500,
      messages: [{ role: 'user', content: prompt }],
    }),
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({}))
    throw new Error(err?.error?.message || `Anthropic API error: ${response.status}`)
  }

  const data = await response.json()
  const script = data.content?.[0]?.text?.trim()

  if (!script) throw new Error('No script returned from AI. Please try again.')

  return script
}

export async function generatePitchFeedback(script) {
  if (!ANTHROPIC_API_KEY) return null

  const prompt = `You are an elite pitch coach. Analyze this startup pitch script and provide brief, actionable feedback in exactly this JSON format (no markdown, pure JSON):
{
  "score": <number 1-100>,
  "strengths": [<string>, <string>],
  "improvements": [<string>, <string>],
  "powerWord": "<most impactful word or phrase in the script>"
}

SCRIPT:
${script}

Return only valid JSON:`

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 400,
      messages: [{ role: 'user', content: prompt }],
    }),
  })

  if (!response.ok) return null

  const data = await response.json()
  const text = data.content?.[0]?.text?.trim()
  try {
    return JSON.parse(text.replace(/```json|```/g, '').trim())
  } catch {
    return null
  }
}
