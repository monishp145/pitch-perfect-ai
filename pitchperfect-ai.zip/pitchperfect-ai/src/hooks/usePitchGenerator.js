// ============================================
// hooks/usePitchGenerator.js
// Central state management for the pitch studio
// ============================================

import { useState, useCallback } from 'react'
import { generatePitchScript, generatePitchFeedback } from '../services/anthropicService.js'
import { synthesizeSpeech } from '../services/murfService.js'

export const STEPS = {
  INPUT: 'input',
  GENERATING: 'generating',
  SCRIPT_READY: 'script_ready',
  SYNTHESIZING: 'synthesizing',
  AUDIO_READY: 'audio_ready',
  ERROR: 'error',
}

export default function usePitchGenerator() {
  const [step, setStep] = useState(STEPS.INPUT)
  const [script, setScript] = useState('')
  const [audioUrl, setAudioUrl] = useState(null)
  const [audioDuration, setAudioDuration] = useState(0)
  const [feedback, setFeedback] = useState(null)
  const [error, setError] = useState(null)
  const [generationProgress, setGenerationProgress] = useState('')

  // Step 1: Generate pitch script with Claude
  const generateScript = useCallback(async (formData) => {
    setError(null)
    setScript('')
    setAudioUrl(null)
    setFeedback(null)
    setStep(STEPS.GENERATING)
    setGenerationProgress('Analyzing your idea...')

    try {
      // Simulate progress messages for better UX
      const progressMessages = [
        'Analyzing your idea...',
        'Crafting your hook...',
        'Building the narrative arc...',
        'Polishing for maximum impact...',
      ]
      let msgIndex = 0
      const progressInterval = setInterval(() => {
        msgIndex = (msgIndex + 1) % progressMessages.length
        setGenerationProgress(progressMessages[msgIndex])
      }, 1800)

      const generatedScript = await generatePitchScript(formData)
      
      clearInterval(progressInterval)
      setScript(generatedScript)
      setStep(STEPS.SCRIPT_READY)

      // Fetch feedback in background (non-blocking)
      generatePitchFeedback(generatedScript).then(fb => {
        if (fb) setFeedback(fb)
      })
    } catch (err) {
      setError(err.message)
      setStep(STEPS.ERROR)
    }
  }, [])

  // Step 2: Synthesize voice with Murf
  const synthesizeVoice = useCallback(async (voiceStyle) => {
    if (!script) return
    setError(null)
    setAudioUrl(null)
    setStep(STEPS.SYNTHESIZING)

    try {
      const result = await synthesizeSpeech(script, voiceStyle)
      setAudioUrl(result.audioUrl)
      setAudioDuration(result.duration)
      setStep(STEPS.AUDIO_READY)
    } catch (err) {
      setError(err.message)
      setStep(STEPS.SCRIPT_READY) // Fall back to script ready, not full error
    }
  }, [script])

  const reset = useCallback(() => {
    setStep(STEPS.INPUT)
    setScript('')
    setAudioUrl(null)
    setAudioDuration(0)
    setFeedback(null)
    setError(null)
    setGenerationProgress('')
  }, [])

  const editScript = useCallback((newScript) => {
    setScript(newScript)
    setAudioUrl(null) // Clear audio when script is edited
    setStep(STEPS.SCRIPT_READY)
  }, [])

  return {
    step,
    script,
    audioUrl,
    audioDuration,
    feedback,
    error,
    generationProgress,
    generateScript,
    synthesizeVoice,
    reset,
    editScript,
  }
}
