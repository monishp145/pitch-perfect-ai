import React, { useState } from 'react'
import { Edit3, Check, Copy, RefreshCw } from 'lucide-react'
import './ScriptEditor.css'

export default function ScriptEditor({ script, onEdit, onRegenerate }) {
  const [isEditing, setIsEditing] = useState(false)
  const [editValue, setEditValue] = useState(script)
  const [copied, setCopied] = useState(false)

  const handleSave = () => {
    onEdit(editValue)
    setIsEditing(false)
  }

  const handleCopy = async () => {
    await navigator.clipboard.writeText(script)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const wordCount = script.trim().split(/\s+/).length
  const estDuration = Math.ceil((wordCount / 140) * 60) // avg 140 wpm

  return (
    <div className="script-editor">
      <div className="script-header">
        <div className="script-meta">
          <span className="tag">Generated Script</span>
          <span className="script-stats">
            {wordCount} words · ~{estDuration}s
          </span>
        </div>
        <div className="script-actions">
          <button className="script-action-btn" onClick={handleCopy} title="Copy script">
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? 'Copied!' : 'Copy'}
          </button>
          <button className="script-action-btn" onClick={onRegenerate} title="Regenerate">
            <RefreshCw size={14} />
            Regenerate
          </button>
          <button
            className={`script-action-btn ${isEditing ? 'active' : ''}`}
            onClick={() => isEditing ? handleSave() : setIsEditing(true)}
          >
            {isEditing ? <Check size={14} /> : <Edit3 size={14} />}
            {isEditing ? 'Save' : 'Edit'}
          </button>
        </div>
      </div>

      <div className="script-body">
        {isEditing ? (
          <textarea
            className="script-textarea"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            rows={12}
            autoFocus
          />
        ) : (
          <div className="script-display">
            {script.split('\n').filter(Boolean).map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
