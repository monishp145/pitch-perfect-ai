import React from 'react'
import { TrendingUp, AlertCircle, Star, Zap } from 'lucide-react'
import './FeedbackPanel.css'

export default function FeedbackPanel({ feedback }) {
  if (!feedback) return null

  const { score, strengths, improvements, powerWord } = feedback

  const scoreColor =
    score >= 80 ? '#4caf7d' : score >= 60 ? '#c9a84c' : '#d94f3d'

  return (
    <div className="feedback-panel">
      <div className="feedback-header">
        <span className="tag"><Zap size={10} /> AI Coach Feedback</span>
      </div>

      <div className="feedback-body">
        <div className="score-section">
          <div className="score-ring" style={{ '--score-color': scoreColor }}>
            <svg viewBox="0 0 80 80">
              <circle cx="40" cy="40" r="32" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" />
              <circle
                cx="40" cy="40" r="32"
                fill="none"
                stroke={scoreColor}
                strokeWidth="6"
                strokeLinecap="round"
                strokeDasharray={`${(score / 100) * 201} 201`}
                transform="rotate(-90 40 40)"
                style={{ transition: 'stroke-dasharray 1s ease' }}
              />
            </svg>
            <div className="score-value">
              <span className="score-number">{score}</span>
              <span className="score-label">/ 100</span>
            </div>
          </div>
          {powerWord && (
            <div className="power-word">
              <Star size={11} />
              <span>Power phrase: <em>"{powerWord}"</em></span>
            </div>
          )}
        </div>

        <div className="feedback-lists">
          {strengths?.length > 0 && (
            <div className="feedback-list strengths">
              <h4><TrendingUp size={13} /> Strengths</h4>
              {strengths.map((s, i) => (
                <div key={i} className="feedback-item">
                  <span className="item-dot green" />
                  <span>{s}</span>
                </div>
              ))}
            </div>
          )}
          {improvements?.length > 0 && (
            <div className="feedback-list improvements">
              <h4><AlertCircle size={13} /> To Improve</h4>
              {improvements.map((imp, i) => (
                <div key={i} className="feedback-item">
                  <span className="item-dot amber" />
                  <span>{imp}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
