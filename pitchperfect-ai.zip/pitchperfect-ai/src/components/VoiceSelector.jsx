import React from 'react'
import { MURF_VOICES } from '../services/murfService.js'
import './VoiceSelector.css'

export default function VoiceSelector({ selectedVoice, onChange, disabled }) {
  return (
    <div className="voice-selector">
      <label className="voice-selector-label">
        <span className="vs-label-text">Select Voice Style</span>
        <span className="vs-powered">Powered by Murf.ai</span>
      </label>
      <div className="voice-cards">
        {Object.entries(MURF_VOICES).map(([key, voice]) => (
          <button
            key={key}
            className={`voice-card ${selectedVoice === key ? 'selected' : ''}`}
            onClick={() => onChange(key)}
            disabled={disabled}
            type="button"
          >
            <span className="voice-card-icon">{voice.icon}</span>
            <div className="voice-card-info">
              <span className="voice-card-name">{key}</span>
              <span className="voice-card-desc">{voice.description}</span>
            </div>
            <div className="voice-card-check">
              {selectedVoice === key && <span className="check-dot" />}
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
