import React, { useState, useRef, useEffect } from 'react'
import { Play, Pause, RotateCcw, Download, Volume2 } from 'lucide-react'
import './AudioPlayer.css'

export default function AudioPlayer({ audioUrl, duration, voiceStyle }) {
  const audioRef = useRef(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [totalDuration, setTotalDuration] = useState(duration || 0)
  const [volume, setVolume] = useState(1)
  const animFrameRef = useRef(null)

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume
    }
  }, [volume])

  useEffect(() => {
    // Reset when new audio
    setIsPlaying(false)
    setCurrentTime(0)
  }, [audioUrl])

  const updateTime = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime)
      if (!audioRef.current.paused) {
        animFrameRef.current = requestAnimationFrame(updateTime)
      }
    }
  }

  const togglePlay = async () => {
    if (!audioRef.current) return
    if (isPlaying) {
      audioRef.current.pause()
      setIsPlaying(false)
      cancelAnimationFrame(animFrameRef.current)
    } else {
      await audioRef.current.play()
      setIsPlaying(true)
      animFrameRef.current = requestAnimationFrame(updateTime)
    }
  }

  const handleSeek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const ratio = (e.clientX - rect.left) / rect.width
    const newTime = ratio * totalDuration
    if (audioRef.current) {
      audioRef.current.currentTime = newTime
      setCurrentTime(newTime)
    }
  }

  const handleRestart = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0
      setCurrentTime(0)
    }
  }

  const handleEnded = () => {
    setIsPlaying(false)
    setCurrentTime(0)
    cancelAnimationFrame(animFrameRef.current)
  }

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setTotalDuration(audioRef.current.duration)
    }
  }

  const handleDownload = () => {
    const a = document.createElement('a')
    a.href = audioUrl
    a.download = `pitchperfect-${voiceStyle?.toLowerCase()}-pitch.mp3`
    a.click()
  }

  const formatTime = (sec) => {
    const m = Math.floor(sec / 60)
    const s = Math.floor(sec % 60)
    return `${m}:${s.toString().padStart(2, '0')}`
  }

  const progress = totalDuration > 0 ? (currentTime / totalDuration) * 100 : 0

  return (
    <div className={`audio-player ${voiceStyle?.toLowerCase()}`}>
      <audio
        ref={audioRef}
        src={audioUrl}
        onEnded={handleEnded}
        onLoadedMetadata={handleLoadedMetadata}
        preload="metadata"
      />

      <div className="player-voice-label">
        <span className="voice-dot" />
        <span>{voiceStyle === 'Promo' ? '🔥 Promo Voice' : '💼 Authoritative Voice'}</span>
      </div>

      {/* Waveform visualization (decorative) */}
      <div className="waveform-container">
        {Array.from({ length: 40 }).map((_, i) => (
          <div
            key={i}
            className={`wave-bar ${isPlaying ? 'animating' : ''} ${(i / 40) * 100 < progress ? 'played' : ''}`}
            style={{
              height: `${20 + Math.sin(i * 0.8) * 12 + Math.cos(i * 0.4) * 8}px`,
              animationDelay: `${(i * 0.05) % 0.5}s`,
            }}
          />
        ))}
      </div>

      {/* Progress bar */}
      <div className="progress-bar-wrapper" onClick={handleSeek}>
        <div className="progress-bar-track">
          <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
          <div className="progress-thumb" style={{ left: `${progress}%` }} />
        </div>
      </div>

      <div className="player-controls">
        <div className="time-display">
          <span>{formatTime(currentTime)}</span>
          <span className="time-sep">/</span>
          <span>{formatTime(totalDuration)}</span>
        </div>

        <div className="control-buttons">
          <button className="ctrl-btn" onClick={handleRestart} title="Restart">
            <RotateCcw size={14} />
          </button>
          <button className="ctrl-btn play-btn" onClick={togglePlay} title={isPlaying ? 'Pause' : 'Play'}>
            {isPlaying ? <Pause size={18} /> : <Play size={18} />}
          </button>
          <button className="ctrl-btn" onClick={handleDownload} title="Download">
            <Download size={14} />
          </button>
        </div>

        <div className="volume-control">
          <Volume2 size={12} />
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="volume-slider"
          />
        </div>
      </div>
    </div>
  )
}
