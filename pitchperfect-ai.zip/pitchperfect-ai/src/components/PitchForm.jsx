import React, { useState } from 'react'
import { Lightbulb, ChevronDown, Sparkles } from 'lucide-react'
import { MURF_VOICES } from '../services/murfService.js'
import './PitchForm.css'

const PITCH_TYPES = ['Elevator Pitch', 'Investor Pitch', 'Demo Day', 'Product Launch']
const DURATIONS = [
  { value: '30s', label: '30 sec', desc: '~80 words' },
  { value: '60s', label: '1 min', desc: '~160 words' },
  { value: '2min', label: '2 min', desc: '~320 words' },
  { value: '5min', label: '5 min', desc: '~800 words' },
]

const EXAMPLE_IDEAS = [
  "An AI-powered study app that creates personalized practice exams from your lecture notes, adapts to your weak areas, and predicts your exam score — helping students study smarter, not harder.",
  "A marketplace connecting local farmers directly with urban restaurants, eliminating middlemen, guaranteeing freshness within 24 hours of harvest, and giving farmers 40% more revenue.",
  "A mental wellness app for college students that uses anonymous peer support circles, AI mood tracking, and connects students to campus counseling — making mental health support as easy as sending a text.",
]

export default function PitchForm({ onSubmit, isLoading }) {
  const [idea, setIdea] = useState('')
  const [voiceStyle, setVoiceStyle] = useState('Promo')
  const [pitchType, setPitchType] = useState('Elevator Pitch')
  const [duration, setDuration] = useState('60s')

  const handleSubmit = () => {
    if (!idea.trim() || isLoading) return
    onSubmit({ idea: idea.trim(), voiceStyle, pitchType, duration })
  }

  const loadExample = () => {
    const random = EXAMPLE_IDEAS[Math.floor(Math.random() * EXAMPLE_IDEAS.length)]
    setIdea(random)
  }

  const charCount = idea.length
  const isReady = idea.trim().length >= 20

  return (
    <div className="pitch-form">
      {/* Idea Textarea */}
      <div className="form-group">
        <div className="form-label-row">
          <label className="form-label">
            <Lightbulb size={13} />
            Your Startup Idea
          </label>
          <button className="example-btn" onClick={loadExample} type="button">
            <Sparkles size={11} />
            Load Example
          </button>
        </div>
        <textarea
          className="idea-textarea"
          placeholder="Describe your startup idea in plain English. What problem does it solve? Who is your target audience? What makes it unique? Don't worry about polish — that's our job..."
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          rows={6}
          maxLength={2000}
        />
        <div className="char-counter">
          <span className={charCount < 20 ? 'warn' : 'ok'}>
            {charCount < 20 ? `${20 - charCount} more characters needed` : `${charCount} / 2000`}
          </span>
        </div>
      </div>

      {/* Pitch Type */}
      <div className="form-group">
        <label className="form-label">
          <span>Pitch Type</span>
        </label>
        <div className="option-grid">
          {PITCH_TYPES.map((type) => (
            <button
              key={type}
              type="button"
              className={`option-pill ${pitchType === type ? 'selected' : ''}`}
              onClick={() => setPitchType(type)}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Duration */}
      <div className="form-group">
        <label className="form-label">Duration</label>
        <div className="duration-grid">
          {DURATIONS.map((d) => (
            <button
              key={d.value}
              type="button"
              className={`duration-card ${duration === d.value ? 'selected' : ''}`}
              onClick={() => setDuration(d.value)}
            >
              <span className="dur-label">{d.label}</span>
              <span className="dur-desc">{d.desc}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Voice Style */}
      <div className="form-group">
        <label className="form-label">Voice Style</label>
        <div className="voice-cards">
          {Object.entries(MURF_VOICES).map(([key, voice]) => (
            <button
              key={key}
              type="button"
              className={`voice-card ${voiceStyle === key ? 'selected' : ''}`}
              onClick={() => setVoiceStyle(key)}
            >
              <div className="voice-card-top">
                <span className="voice-emoji">{voice.icon}</span>
                <div className="voice-selected-dot" />
              </div>
              <div className="voice-card-label">{voice.label}</div>
              <div className="voice-card-desc">{voice.description}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Submit */}
      <button
        className="btn btn-primary submit-btn"
        onClick={handleSubmit}
        disabled={!isReady || isLoading}
      >
        {isLoading ? (
          <>
            <span className="spinner" />
            Generating Your Pitch...
          </>
        ) : (
          <>
            <Sparkles size={15} />
            Generate My Pitch Script
          </>
        )}
      </button>
    </div>
  )
}
