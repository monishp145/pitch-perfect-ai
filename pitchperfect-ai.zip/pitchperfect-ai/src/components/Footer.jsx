import React from 'react'
import { Link } from 'react-router-dom'
import { Mic, Github, Twitter } from 'lucide-react'
import './Footer.css'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div className="footer-brand">
          <div className="footer-logo">
            <div className="footer-logo-icon"><Mic size={14} /></div>
            <span>PITCH<span>PERFECT</span> AI</span>
          </div>
          <p className="footer-tagline">
            From raw idea to boardroom-ready pitch — powered by AI, refined for founders.
          </p>
        </div>

        <div className="footer-links">
          <div className="footer-col">
            <h4>Product</h4>
            <Link to="/">Home</Link>
            <Link to="/studio">Pitch Studio</Link>
            <Link to="/how-it-works">How It Works</Link>
          </div>
          <div className="footer-col">
            <h4>Powered By</h4>
            <a href="https://anthropic.com" target="_blank" rel="noopener">Claude AI</a>
            <a href="https://murf.ai" target="_blank" rel="noopener">Murf.ai</a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="container">
          <span className="footer-copy">© {new Date().getFullYear()} PitchPerfect AI. Built for student entrepreneurs.</span>
          <div className="footer-social">
            <a href="#" aria-label="GitHub"><Github size={16} /></a>
            <a href="#" aria-label="Twitter"><Twitter size={16} /></a>
          </div>
        </div>
      </div>
    </footer>
  )
}
