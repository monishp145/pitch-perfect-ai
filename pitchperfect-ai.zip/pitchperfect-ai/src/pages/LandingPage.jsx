import React from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Mic, Sparkles, Volume2, Target, ChevronRight, Zap, Award, Users } from 'lucide-react'
import './LandingPage.css'

const TICKER_ITEMS = [
  'PITCH PERFECT', 'INVESTOR READY', 'AI POWERED', 'MURF VOICES',
  'DEMO DAY', 'SEED ROUND', 'SERIES A', 'YOUR IDEA',
]

const FEATURES = [
  {
    icon: <Sparkles size={22} />,
    title: 'Claude-Powered Script Generation',
    desc: 'Paste your raw idea. Claude AI transforms it into a structured, high-impact pitch script tailored to your audience and duration.',
  },
  {
    icon: <Volume2 size={22} />,
    title: 'Murf.ai Voice Narration',
    desc: 'Hear your pitch in Murf\'s professional Promo or Authoritative voice styles — so you know exactly how it should sound.',
  },
  {
    icon: <Target size={22} />,
    title: 'Pitch Coach Feedback',
    desc: 'Get an AI score, identify your power phrases, and receive concrete improvements to sharpen your message.',
  },
  {
    icon: <Award size={22} />,
    title: 'Multiple Pitch Types',
    desc: 'Elevator pitch, investor deck, demo day, product launch — every format crafted and optimized for the right moment.',
  },
]

const STATS = [
  { value: '4 Types', label: 'Pitch Formats' },
  { value: '2 Voices', label: 'Murf AI Styles' },
  { value: '< 60s', label: 'Generation Time' },
  { value: '100pt', label: 'Coach Score' },
]

export default function LandingPage() {
  return (
    <div className="landing">

      {/* Ticker */}
      <div className="ticker-bar" aria-hidden="true">
        <div className="ticker-track">
          {[...TICKER_ITEMS, ...TICKER_ITEMS].map((item, i) => (
            <span key={i} className="ticker-item">
              <span className="ticker-dot" />
              {item}
            </span>
          ))}
        </div>
      </div>

      {/* Hero */}
      <section className="hero">
        <div className="hero-bg-grid" aria-hidden="true" />
        <div className="hero-glow" aria-hidden="true" />

        <div className="container hero-content">
          <div className="hero-badge">
            <Mic size={12} />
            <span>AI Pitch Coach for Student Entrepreneurs</span>
          </div>

          <h1 className="hero-title">
            <span className="hero-title-line display-text">FROM IDEA</span>
            <span className="hero-title-line display-text accent">TO PITCH</span>
            <span className="hero-title-line display-text">IN SECONDS.</span>
          </h1>

          <p className="hero-subtitle serif-text">
            PitchPerfect AI turns your raw startup idea into a boardroom-ready script — 
            then reads it back to you in a professional investor voice, so you can 
            <em> hear your brand</em> before you ever step on stage.
          </p>

          <div className="hero-actions">
            <Link to="/studio" className="btn btn-primary hero-cta">
              Start Pitching <ArrowRight size={16} />
            </Link>
            <Link to="/how-it-works" className="btn btn-outline">
              See How It Works
            </Link>
          </div>

          <div className="hero-stats">
            {STATS.map((s, i) => (
              <div key={i} className="stat-item">
                <span className="stat-value display-text">{s.value}</span>
                <span className="stat-label">{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Hero preview card */}
        <div className="container">
          <div className="hero-preview">
            <div className="preview-label">
              <span className="preview-dot" />
              <span className="mono-text">LIVE DEMO — GENERATING PITCH...</span>
            </div>
            <div className="preview-script">
              <p className="serif-text">
                "Imagine a world where every student founder walks into their first pitch 
                meeting with the confidence of a seasoned CEO. That world starts today. 
                PitchPerfect AI — because your idea deserves a voice worthy of it."
              </p>
            </div>
            <div className="preview-footer">
              <div className="preview-voice-badge promo">🔥 Promo Voice</div>
              <div className="preview-voice-badge auth">💼 Authoritative Voice</div>
              <span className="preview-score mono-text">Coach Score: <strong>94/100</strong></span>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="features-section">
        <div className="container">
          <div className="section-header">
            <span className="tag">What We Do</span>
            <h2 className="section-title display-text">BUILT FOR<br/>FOUNDERS WHO<br/>MEAN BUSINESS.</h2>
          </div>

          <div className="features-grid">
            {FEATURES.map((f, i) => (
              <div key={i} className="feature-card">
                <div className="feature-icon">{f.icon}</div>
                <h3 className="feature-title">{f.title}</h3>
                <p className="feature-desc">{f.desc}</p>
                <div className="feature-corner" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Voice Section */}
      <section className="voices-section">
        <div className="container">
          <div className="voices-inner">
            <div className="voices-text">
              <span className="tag"><Volume2 size={10} /> Powered by Murf.ai</span>
              <h2 className="voices-title display-text">HEAR YOUR BRAND BEFORE THE BOARDROOM.</h2>
              <p className="voices-desc serif-text">
                Most founders rehearse in silence. PitchPerfect AI lets you hear your pitch 
                delivered in two professionally calibrated voice styles — so you internalize 
                the right pace, emphasis, and authority.
              </p>
              <div className="voice-cards">
                <div className="voice-card">
                  <span className="voice-emoji">🔥</span>
                  <div>
                    <strong>Promo</strong>
                    <p>Energetic, inspiring, emotionally resonant. Ideal for demo days and launch events.</p>
                  </div>
                </div>
                <div className="voice-card">
                  <span className="voice-emoji">💼</span>
                  <div>
                    <strong>Authoritative</strong>
                    <p>Confident, precise, commanding. Built for investor meetings and board presentations.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="voices-visual" aria-hidden="true">
              <div className="waveform-demo">
                {Array.from({ length: 30 }).map((_, i) => (
                  <div key={i} className="wdemo-bar" style={{
                    height: `${18 + Math.sin(i * 0.7) * 14 + Math.cos(i * 0.4) * 8}px`,
                    animationDelay: `${(i * 0.07) % 1}s`,
                  }} />
                ))}
              </div>
              <div className="voices-label mono-text">MURF.AI VOICE ENGINE</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta-section">
        <div className="container">
          <div className="cta-box">
            <div className="cta-corner tl" />
            <div className="cta-corner br" />
            <Users size={28} style={{ color: 'var(--gold)', marginBottom: '1rem' }} />
            <h2 className="cta-title display-text">YOUR IDEA HAS A VOICE.<br/>LET'S FIND IT.</h2>
            <p className="cta-subtitle serif-text">
              Join student entrepreneurs turning rough concepts into polished pitches — 
              no communication training required.
            </p>
            <Link to="/studio" className="btn btn-primary cta-btn">
              Open Pitch Studio <ChevronRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
