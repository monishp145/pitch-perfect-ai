import React, { useState } from 'react'
import { Mic, Loader2, AlertCircle, RotateCcw, Volume2, ArrowRight } from 'lucide-react'
import usePitchGenerator, { STEPS } from '../hooks/usePitchGenerator.js'
import { MURF_VOICES } from '../services/murfService.js'
import ScriptEditor from '../components/ScriptEditor.jsx'
import AudioPlayer from '../components/AudioPlayer.jsx'
import FeedbackPanel from '../components/FeedbackPanel.jsx'
import './PitchStudio.css'

const PITCH_TYPES = ['Elevator Pitch', 'Investor Pitch', 'Demo Day', 'Product Launch']
const DURATIONS = [
  { value: '30s', label: '30 sec' },
  { value: '60s', label: '1 min' },
  { value: '2min', label: '2 min' },
  { value: '5min', label: '5 min' },
]

export default function PitchStudio() {
  const [formData, setFormData] = useState({
    idea: '',
    pitchType: 'Elevator Pitch',
    duration: '60s',
    voiceStyle: 'Promo',
  })

  const {
    step, script, audioUrl, audioDuration, feedback,
    error, generationProgress,
    generateScript, synthesizeVoice, reset, editScript,
  } = usePitchGenerator()

  const handleGenerate = (e) => {
    e.preventDefault()
    if (!formData.idea.trim()) return
    generateScript(formData)
  }

  const handleVoiceChange = (style) => {
    setFormData(f => ({ ...f, voiceStyle: style }))
  }

  const handleSynthesize = () => {
    synthesizeVoice(formData.voiceStyle)
  }

  const handleRegenerate = () => {
    generateScript(formData)
  }

  const isGenerating = step === STEPS.GENERATING
  const isSynthesizing = step === STEPS.SYNTHESIZING
  const hasScript = step === STEPS.SCRIPT_READY || step === STEPS.AUDIO_READY || isSynthesizing
  const hasAudio = step === STEPS.AUDIO_READY
  const hasError = step === STEPS.ERROR

  return (
    <div className="studio-page">
      <div className="studio-bg-grid" aria-hidden="true" />

      <div className="container studio-container">

        {/* Page Header */}
        <div className="studio-header">
          <div className="studio-header-left">
            <div className="studio-icon"><Mic size={20} /></div>
            <div>
              <h1 className="studio-title display-text">PITCH STUDIO</h1>
              <p className="studio-subtitle">Your AI-powered pitch coach</p>
            </div>
          </div>
          {step !== STEPS.INPUT && (
            <button className="btn btn-outline reset-btn" onClick={reset}>
              <RotateCcw size={14} /> New Pitch
            </button>
          )}
        </div>

        <div className="studio-layout">

          {/* LEFT: Input Panel */}
          <div className={`studio-input-panel ${hasScript ? 'collapsed' : ''}`}>
            <div className="panel-label mono-text">01 — YOUR IDEA</div>

            <form onSubmit={handleGenerate} className="pitch-form">
              {/* Idea Input */}
              <div className="form-group">
                <label className="form-label">Describe Your Startup Idea</label>
                <textarea
                  className="idea-textarea"
                  placeholder="e.g. An app that connects local farmers directly to consumers, eliminating middlemen and reducing food waste by 40%. Uses AI to predict supply and demand, ensuring farmers get fair prices and consumers get fresh produce delivered same-day..."
                  value={formData.idea}
                  onChange={e => setFormData(f => ({ ...f, idea: e.target.value }))}
                  rows={6}
                  disabled={isGenerating}
                  required
                />
                <div className="char-count mono-text">
                  {formData.idea.length} chars
                </div>
              </div>

              {/* Pitch Type */}
              <div className="form-group">
                <label className="form-label">Pitch Type</label>
                <div className="option-grid">
                  {PITCH_TYPES.map(type => (
                    <button
                      key={type}
                      type="button"
                      className={`option-btn ${formData.pitchType === type ? 'selected' : ''}`}
                      onClick={() => setFormData(f => ({ ...f, pitchType: type }))}
                      disabled={isGenerating}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Duration */}
              <div className="form-group">
                <label className="form-label">Target Duration</label>
                <div className="option-grid duration-grid">
                  {DURATIONS.map(d => (
                    <button
                      key={d.value}
                      type="button"
                      className={`option-btn ${formData.duration === d.value ? 'selected' : ''}`}
                      onClick={() => setFormData(f => ({ ...f, duration: d.value }))}
                      disabled={isGenerating}
                    >
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Voice Style */}
              <div className="form-group">
                <label className="form-label">Voice Style <span className="powered-by">powered by Murf.ai</span></label>
                <div className="voice-selector">
                  {Object.entries(MURF_VOICES).map(([key, voice]) => (
                    <button
                      key={key}
                      type="button"
                      className={`voice-option ${formData.voiceStyle === key ? 'selected' : ''}`}
                      onClick={() => handleVoiceChange(key)}
                      disabled={isGenerating}
                    >
                      <span className="voice-emoji">{voice.icon}</span>
                      <div className="voice-info">
                        <strong>{voice.label}</strong>
                        <p>{voice.description}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="btn btn-primary generate-btn"
                disabled={isGenerating || !formData.idea.trim()}
              >
                {isGenerating ? (
                  <><Loader2 size={16} className="spin" /> {generationProgress}</>
                ) : (
                  <>Generate Pitch Script <ArrowRight size={16} /></>
                )}
              </button>
            </form>
          </div>

          {/* RIGHT: Output Panel */}
          <div className="studio-output-panel">

            {/* Error State */}
            {hasError && (
              <div className="error-card">
                <AlertCircle size={20} />
                <div>
                  <strong>Something went wrong</strong>
                  <p>{error}</p>
                </div>
                <button className="btn btn-outline" onClick={reset}>Try Again</button>
              </div>
            )}

            {/* Generating State */}
            {isGenerating && (
              <div className="generating-state">
                <div className="gen-animation">
                  {Array.from({ length: 12 }).map((_, i) => (
                    <div key={i} className="gen-dot" style={{ animationDelay: `${i * 0.12}s` }} />
                  ))}
                </div>
                <p className="gen-label mono-text">{generationProgress}</p>
                <p className="gen-sub serif-text">Claude is crafting your pitch...</p>
              </div>
            )}

            {/* Script Ready */}
            {hasScript && (
              <div className="output-stack">
                <div className="panel-label mono-text">02 — YOUR SCRIPT</div>

                <ScriptEditor
                  script={script}
                  onEdit={editScript}
                  onRegenerate={handleRegenerate}
                />

                {feedback && <FeedbackPanel feedback={feedback} />}

                {/* Voice section */}
                <div className="panel-label mono-text" style={{ marginTop: '0.5rem' }}>
                  03 — HEAR YOUR PITCH
                </div>

                <div className="voice-section">
                  {/* Voice style selector for audio */}
                  <div className="audio-voice-select">
                    {Object.entries(MURF_VOICES).map(([key, voice]) => (
                      <button
                        key={key}
                        type="button"
                        className={`voice-tab ${formData.voiceStyle === key ? 'active' : ''}`}
                        onClick={() => handleVoiceChange(key)}
                        disabled={isSynthesizing}
                      >
                        {voice.icon} {key}
                      </button>
                    ))}
                  </div>

                  {!hasAudio && !isSynthesizing && (
                    <button
                      className="btn btn-primary synthesize-btn"
                      onClick={handleSynthesize}
                    >
                      <Volume2 size={16} />
                      Generate Voice Narration
                    </button>
                  )}

                  {isSynthesizing && (
                    <div className="synth-loading">
                      <Loader2 size={16} className="spin" />
                      <span className="mono-text">Murf.ai is generating your voice...</span>
                    </div>
                  )}

                  {error && !hasError && (
                    <div className="voice-error">
                      <AlertCircle size={14} />
                      <span>{error}</span>
                    </div>
                  )}

                  {hasAudio && (
                    <AudioPlayer
                      audioUrl={audioUrl}
                      duration={audioDuration}
                      voiceStyle={formData.voiceStyle}
                    />
                  )}

                  {hasAudio && (
                    <button
                      className="btn btn-outline re-synthesize-btn"
                      onClick={handleSynthesize}
                    >
                      <RotateCcw size={13} />
                      Re-generate with {formData.voiceStyle === 'Promo' ? '💼 Authoritative' : '🔥 Promo'} voice
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Empty state */}
            {step === STEPS.INPUT && !isGenerating && (
              <div className="empty-state">
                <div className="empty-icon">
                  <Mic size={32} />
                </div>
                <h3 className="display-text">YOUR PITCH<br/>AWAITS.</h3>
                <p className="serif-text">
                  Fill in your startup idea on the left and hit Generate. 
                  Claude will craft a professional pitch script in seconds.
                </p>
                <div className="empty-steps">
                  <div className="empty-step"><span>01</span> Describe your idea</div>
                  <div className="empty-step"><span>02</span> Get AI-generated script</div>
                  <div className="empty-step"><span>03</span> Hear it in Murf voice</div>
                </div>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  )
}
