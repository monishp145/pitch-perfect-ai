import React from 'react'
import { Link } from 'react-router-dom'
import { Edit3, Cpu, Volume2, TrendingUp, ArrowRight, CheckCircle } from 'lucide-react'
import './HowItWorks.css'

const STEPS = [
  {
    num: '01',
    icon: <Edit3 size={24} />,
    title: 'Describe Your Idea',
    desc: 'Write your raw startup concept in plain language — no polishing needed. Just tell us what problem you solve, who you serve, and what makes you different.',
    details: ['Any stage of idea', 'No formatting required', 'Be as rough as you like'],
  },
  {
    num: '02',
    icon: <Cpu size={24} />,
    title: 'AI Generates Your Script',
    desc: "Claude AI analyzes your idea and structures it into a professional pitch script using proven frameworks — hook, problem, solution, value prop, vision, and CTA.",
    details: ['Powered by Claude (Anthropic)', '4 pitch formats available', 'Editable output'],
  },
  {
    num: '03',
    icon: <Volume2 size={24} />,
    title: 'Hear Your Brand Voice',
    desc: "Murf.ai's professional voice engine narrates your pitch in Promo or Authoritative style — so you hear exactly how your pitch should sound.",
    details: ['Murf.ai Promo voice', 'Murf.ai Authoritative voice', 'Downloadable MP3'],
  },
  {
    num: '04',
    icon: <TrendingUp size={24} />,
    title: 'Get Coach Feedback',
    desc: 'Receive an AI pitch score, identify your strongest phrases, and get concrete suggestions to make your pitch even more compelling before the big day.',
    details: ['100-point score', 'Strengths & improvements', 'Power phrase detection'],
  },
]

const FAQS = [
  {
    q: 'Do I need any writing or communication skills?',
    a: 'Not at all. PitchPerfect AI is designed for founders who have the idea but not the words. Just describe your concept and the AI does the rest.',
  },
  {
    q: 'What is Murf.ai and why are you using it?',
    a: "Murf.ai is one of the world's leading AI voice platforms, trusted by professionals for high-quality, natural-sounding narration. We use their Promo and Authoritative voice styles specifically because they mirror the tones used in successful investor pitches and product launches.",
  },
  {
    q: 'Can I edit the generated script?',
    a: 'Yes. After your script is generated, you can edit it directly in the Pitch Studio. Any changes will be reflected when you re-generate the voice narration.',
  },
  {
    q: 'What API keys do I need?',
    a: 'You need two keys: an Anthropic API key (for Claude AI) and a Murf.ai API key (for voice synthesis). Both are available from their respective developer portals.',
  },
  {
    q: 'Is the audio downloadable?',
    a: 'Yes. Once your voice narration is generated, you can download the MP3 directly from the audio player in the Pitch Studio.',
  },
]

export default function HowItWorks() {
  return (
    <div className="hiw-page">
      <div className="container">

        {/* Header */}
        <div className="hiw-header">
          <span className="tag">The Process</span>
          <h1 className="hiw-title display-text">HOW IT<br/>WORKS.</h1>
          <p className="hiw-subtitle serif-text">
            Four steps from rough idea to boardroom-ready pitch. No experience required.
          </p>
        </div>

        {/* Steps */}
        <div className="steps-list">
          {STEPS.map((step, i) => (
            <div key={i} className="step-row">
              <div className="step-num display-text">{step.num}</div>
              <div className="step-icon">{step.icon}</div>
              <div className="step-content">
                <h2 className="step-title">{step.title}</h2>
                <p className="step-desc">{step.desc}</p>
                <div className="step-details">
                  {step.details.map((d, j) => (
                    <div key={j} className="step-detail">
                      <CheckCircle size={12} />
                      <span>{d}</span>
                    </div>
                  ))}
                </div>
              </div>
              {i < STEPS.length - 1 && <div className="step-connector" />}
            </div>
          ))}
        </div>

        <div className="divider" />

        {/* Tech Stack */}
        <div className="tech-section">
          <h2 className="tech-title display-text">THE TECH STACK.</h2>
          <div className="tech-cards">
            <div className="tech-card">
              <div className="tech-logo anthropic">AN</div>
              <div>
                <strong>Claude by Anthropic</strong>
                <p>Script generation, pitch structuring, and AI coach feedback via the claude-sonnet model.</p>
              </div>
            </div>
            <div className="tech-card">
              <div className="tech-logo murf">M</div>
              <div>
                <strong>Murf.ai Voice Engine</strong>
                <p>Professional Promo and Authoritative voice narration. 48kHz stereo MP3 output.</p>
              </div>
            </div>
            <div className="tech-card">
              <div className="tech-logo react">R</div>
              <div>
                <strong>React + Vite</strong>
                <p>Fast, modern frontend built with React 18, React Router, and Vite for instant HMR.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="divider" />

        {/* FAQ */}
        <div className="faq-section">
          <h2 className="faq-title display-text">COMMON QUESTIONS.</h2>
          <div className="faq-list">
            {FAQS.map((faq, i) => (
              <details key={i} className="faq-item">
                <summary className="faq-q">{faq.q}</summary>
                <p className="faq-a serif-text">{faq.a}</p>
              </details>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="hiw-cta">
          <Link to="/studio" className="btn btn-primary hiw-cta-btn">
            Open Pitch Studio <ArrowRight size={16} />
          </Link>
        </div>

      </div>
    </div>
  )
}
